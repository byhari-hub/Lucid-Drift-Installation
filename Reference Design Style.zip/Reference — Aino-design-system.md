# Aino Agency — Design System Reference & AI Prompt
> **Usage:** This document is implementation-ready and functions as a secondary prompt. Paste it directly as system context for any AI coding or design assistant to reproduce this visual system faithfully.

---

## 1. Design Philosophy

This visual system is built on **editorial minimalism**: monochromatic, typographically-driven, with extreme whitespace as the primary compositional tool. Every decision prioritizes legibility over decoration. The design communicates authority and restraint — a signature of Scandinavian/Nordic design culture applied to a digital-native context.

**Core principles:**
- Absence over addition. No color, no borders, no dividers, no decorative elements.
- Weight and opacity encode hierarchy — not size alone.
- Grid and spatial rhythm carry all structure.
- Type is the visual. The letterforms are the design.

---

## 2. Typography System

### 2.1 Font Families

| Role | Font Family | Fallback Stack |
|---|---|---|
| **Display / Hero / Body** | PP Nikkei Maru | `'PP Nikkei Maru', 'Inter', sans-serif` |
| **Subheadings / UI Labels / Pillar Body** | Inter | `'Inter', 'Neue Haas Grotesk', 'GT America', sans-serif` |

**Rationale:**
- **PP Nikkei Maru** is a rounded geometric sans with neutral, open letterforms. Apply across all major typographic moments: hero statements, section headings, standard body paragraphs. Its softness at large sizes gives the display text warmth without sacrificing precision.
- **Inter / Neue Haas Grotesk** handles all small-scale utility text — pillar subtitles, meta labels, index numbers, UI captions. These faces share PP Nikkei Maru's neutrality but carry sharper terminals suited to small optical sizes.

### 2.2 Type Scale

| Level | Font | Size (clamp) | Weight | Letter-spacing | Line-height | Usage |
|---|---|---|---|---|---|---|
| **Hero / Display** | PP Nikkei Maru | `clamp(40px, 5vw, 68px)` | 700 | `-0.02em` | `1.10–1.15` | Full-width manifesto statements, mission text |
| **Section Heading** | PP Nikkei Maru | `clamp(28px, 3.5vw, 44px)` | 700 | `-0.015em` | `1.15` | Secondary statement heads |
| **Body / Standard** | PP Nikkei Maru | `14px` | 400 | `0em` | `1.65` | Standard paragraph body text |
| **Subheading / Pillar Title** | Inter | `11px` | 500 | `+0.13em` | `1.4` | ALL CAPS section labels, pillar headers, column headers |
| **Pillar Body** | Inter | `13–13.5px` | 400 | `+0.01em` | `1.65` | Pillar descriptions, meta text |
| **Index / Mono** | Inter | `11px` | 400 | `0em` | `1.4` | Numbered list indices (001, 002…), use tabular figures |
| **Year / Trailing Meta** | Inter | `11px` | 400 | `0em` | `1.4` | Right-aligned year values in client list |

### 2.3 Font Usage Rules

- ALL CAPS is used **exclusively** on labels at `11px` with Inter, never on body or display.
- `font-feature-settings: 'tnum' 1` must be applied to all numeric columns (index numbers, years) for aligned tabular figures.
- PP Nikkei Maru's rounded terminals mean display text should **not** use additional tracking** — its natural spacing already reads well. Only tighten with negative tracking at large sizes (`-0.02em` at hero scale).
- Inter subheadings at `11px` require `+0.12–0.15em` letter-spacing to remain legible at small sizes.
- Active / current items: `font-weight: 700`, `color: #FFFFFF`
- Inactive / historical items: `font-weight: 400`, `color: rgba(255,255,255,0.38)`

---

## 3. Color System

### 3.1 Palette

| Token | Hex / Value | Usage |
|---|---|---|
| `--bg` | `#1C1C1C` | Full-page background, all sections |
| `--text-primary` | `#FFFFFF` | Active client names, hero text, bold labels |
| `--text-secondary` | `rgba(255,255,255,0.38)` | Inactive clients, column headers, ghost items |
| `--text-tertiary` | `rgba(255,255,255,0.22)` | Deeply muted metadata, timestamps |

**No accent color.** No borders. No dividers. No shadows. The system is intentionally 2-color.

### 3.2 Color Logic by Component

| Component | Color | Opacity |
|---|---|---|
| Hero/display text | `#FFF` | 100% |
| Active client name | `#FFF`, weight 700 | 100% |
| Inactive client name | `#FFF`, weight 400 | 38% |
| Column headers ("FACTS", "FOUNDED") | `#FFF`, weight 500 | 38–40% |
| Index numbers | `#FFF`, weight 400 | 38% |
| Year values | `#FFF`, weight 400 | 38% |
| Pillar titles (ALL CAPS labels) | `#FFF`, weight 500 | 38–40% |
| Pillar body text | `#FFF`, weight 400 | 100% |

---

## 4. Grid System & Layout

### 4.1 Global Layout Rules

```
Max content width:   1520px
Outer horizontal margin:  4vw (fluid, min ~48px on desktop)
Section vertical padding: 80–120px top and bottom
```

No horizontal rules, dividers, or border elements anywhere. All separation is achieved through whitespace.

---

### 4.2 Section-by-Section Grid Breakdown

#### Section A — Facts / Client List (4-Column Table Grid)

```
Layout type: 4-column fixed-role table
Columns:     [Index] [Client Name] [Empty/Spacer] [Year]
```

| Column | Role | Start Position | Alignment |
|---|---|---|---|
| Col 1 | Index (`001`, `002`…) | `~2% from left` | Left |
| Col 2 | Client Name | `~25% from left` | Left |
| Col 3 | Empty spacer | `~50%` | — |
| Col 4 | Year | `~96–97% from left` | Right |

**Row specs:**
- Row height: `22–24px`
- No row borders or dividers
- Active rows: weight 700, full white
- Inactive rows: weight 400, `rgba(255,255,255,0.38)`
- Header row (`FACTS | FOUNDED | EMPLOYEES | OFFICES`) uses the same muted weight as inactive rows — it is structural, not dominant

**Header bar** (above client list):
- 4-column rule repeated: `FACTS | FOUNDED | EMPLOYEES | OFFICES`
- Each column header aligns to the same start position as its data column
- No visual separation between header and rows

---

#### Section B — About / Mission (Hero + 2×2 Pillar Grid)

```
Layout type:      Centered editorial with 2-column pillar grid
Hero behavior:    Full-width centered, with ~15% margin on each side
Pillar grid:      2 columns × 2 rows
```

**Hero Text Block:**
- Width: `~70% of viewport`
- Centering: Horizontally centered on the page
- Top margin from section start: `80px`
- Bottom margin before pillar grid: `80–100px`
- Font: PP Nikkei Maru, Hero scale, weight 700

**Pillar Grid:**

```
2 columns, equal width
Column width:   ~40% of viewport each
Gutter:         ~5% of viewport (~48–64px at 1400px wide)
Row gap:        40–48px between pillar rows
```

| Pillar | Position |
|---|---|
| Concept to Code | Col 1, Row 1 |
| Built for Ambition | Col 2, Row 1 |
| Rooted in Humanity | Col 1, Row 2 |
| Business and Pleasure | Col 2, Row 2 |

Each pillar:
- Title: Inter, `11px`, weight 500, ALL CAPS, tracking `+0.13em`
- Gap between title and body: `8–12px`
- Body: Inter, `13.5px`, weight 400, `line-height: 1.65`
- No wrapping box, card, or border — raw text block only

---

#### Section C — Mission Statement (Asymmetric Split Layout)

```
Layout type:    Asymmetric 2-zone composition
Zone 1 (Left):  Hero/manifesto text, bleeding from left margin
Zone 2 (Right): 2-column pillar grid, right-aligned
```

**Zone 1 — Left-aligned Hero:**
- Text starts at outer left margin (`~4vw`)
- Width: approximately `52–58% of viewport`
- Alignment: Ragged left, no centering
- Font: PP Nikkei Maru, Hero scale, weight 700, line-height `1.1`
- Top padding: `80–100px`

**Zone 2 — Right-anchored Pillars:**
- Right edge: flush to outer right margin (`~4vw from right`)
- Width: `~52% of viewport` (overlaps compositionally with Zone 1 below the hero)
- Internal structure: 2 columns × 2 rows

```
Column width:   ~46% of Zone 2 each
Gutter:         ~8% of Zone 2
Row gap:        40–48px
```

| Pillar | Position |
|---|---|
| Turning Shopping into Brand Experience | Col 1, Row 1 |
| People Before Products | Col 2, Row 1 |
| Creative Meets Commercial | Col 1, Row 2 |
| Embrace Simplicity | Col 2, Row 2 |

**Compositional intent:** The left-heavy hero and right-anchored pillar block create a deliberate visual counterweight. The two zones do not share a baseline — the pillars sit in the lower half of the section, anchored to the bottom, while the hero occupies the upper-left.

---

### 4.3 Spacing Tokens

```css
--space-section-v:    100px;   /* Top/bottom padding per section */
--space-hero-to-sub:  80px;    /* Hero text bottom margin to next content block */
--space-pillar-gap-v: 48px;    /* Vertical gap between pillar rows */
--space-pillar-gap-h: 48–64px; /* Horizontal gutter between pillar columns */
--space-label-to-body: 10px;   /* Pillar title to pillar body */
--space-outer-margin: 4vw;     /* Side margins, min 48px */
--max-width: 1520px;
```

---

## 5. CSS Custom Properties — Implementation Reference

```css
:root {
  /* Color */
  --bg:                #1C1C1C;
  --text-primary:      #FFFFFF;
  --text-secondary:    rgba(255, 255, 255, 0.38);
  --text-tertiary:     rgba(255, 255, 255, 0.22);

  /* Typography */
  --font-display:      'PP Nikkei Maru', 'Inter', sans-serif;
  --font-ui:           'Inter', 'Neue Haas Grotesk', 'GT America', sans-serif;

  --size-hero:         clamp(40px, 5vw, 68px);
  --size-heading:      clamp(28px, 3.5vw, 44px);
  --size-body:         14px;
  --size-subheading:   11px;
  --size-pillar-body:  13.5px;
  --size-index:        11px;

  --weight-bold:       700;
  --weight-medium:     500;
  --weight-regular:    400;

  --leading-hero:      1.12;
  --leading-body:      1.65;

  --tracking-hero:     -0.02em;
  --tracking-label:    0.13em;
  --tracking-body:     0em;

  /* Layout */
  --max-width:         1520px;
  --outer-margin:      4vw;
  --space-section-v:   100px;
  --space-hero-to-sub: 80px;
  --space-pillar-gap-v:48px;
  --space-pillar-gap-h:clamp(32px, 4vw, 64px);
  --space-label-body:  10px;
}
```

---

## 6. Component Patterns

### Hero Block
```css
.hero {
  font-family: var(--font-display);
  font-size: var(--size-hero);
  font-weight: var(--weight-bold);
  line-height: var(--leading-hero);
  letter-spacing: var(--tracking-hero);
  color: var(--text-primary);
}
```

### Pillar Title (Subheading)
```css
.pillar-title {
  font-family: var(--font-ui);
  font-size: var(--size-subheading);
  font-weight: var(--weight-medium);
  letter-spacing: var(--tracking-label);
  text-transform: uppercase;
  color: var(--text-secondary);
  margin-bottom: var(--space-label-body);
}
```

### Pillar Body
```css
.pillar-body {
  font-family: var(--font-ui);
  font-size: var(--size-pillar-body);
  font-weight: var(--weight-regular);
  line-height: var(--leading-body);
  letter-spacing: 0.01em;
  color: var(--text-primary);
}
```

### Client List Row (Active)
```css
.client-row--active {
  font-family: var(--font-display);
  font-size: var(--size-body);
  font-weight: var(--weight-bold);
  color: var(--text-primary);
  font-feature-settings: 'tnum' 1;
}
```

### Client List Row (Inactive)
```css
.client-row--inactive {
  font-family: var(--font-display);
  font-size: var(--size-body);
  font-weight: var(--weight-regular);
  color: var(--text-secondary);
  font-feature-settings: 'tnum' 1;
}
```

### Standard Body Text
```css
.body {
  font-family: var(--font-display);
  font-size: var(--size-body);
  font-weight: var(--weight-regular);
  line-height: var(--leading-body);
  letter-spacing: var(--tracking-body);
  color: var(--text-primary);
}
```

---

## 7. Grid Templates (CSS Grid)

### 4-Column Table Grid (Client List)
```css
.client-list {
  display: grid;
  grid-template-columns: 6% 44% 1fr auto;
  column-gap: 0;
  row-gap: 0;
  padding: 0 var(--outer-margin);
}
```

### 2×2 Pillar Grid (Centered / Symmetric)
```css
.pillar-grid--centered {
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: var(--space-pillar-gap-h);
  row-gap: var(--space-pillar-gap-v);
  max-width: 70%;
  margin: 0 auto;
}
```

### Asymmetric Split Layout (Mission Section)
```css
.mission-section {
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: 0;
  padding: var(--space-section-v) var(--outer-margin);
}

.mission-hero {
  grid-column: 1;
  align-self: start;
}

.mission-pillars {
  grid-column: 2;
  align-self: end;
  display: grid;
  grid-template-columns: 1fr 1fr;
  column-gap: clamp(24px, 3vw, 48px);
  row-gap: var(--space-pillar-gap-v);
}
```

---

## 8. Responsiveness Notes

- Below `900px`: Collapse all multi-column pillar grids to a single column.
- Below `680px`: Hero font reduces to a fixed `32px`; remove negative tracking.
- Client list: On mobile, hide the index column; stack client name and year on separate lines.
- Outer margin: Floor at `24px` on small screens.
- No breakpoint-specific color or font changes — the monochromatic palette requires no adaptation.

---

## 9. What to Exclude

The following are explicitly **not part of this system** and must not be introduced:
- Accent colors of any kind
- Borders, dividers, or horizontal rules
- Drop shadows, gradients, or blur effects
- Background cards or container surfaces
- Icon libraries or decorative imagery
- Hover animations beyond opacity transitions
- Rounded-corner UI components (cards, pills, badges)

---

*End of design system reference. This document is structured for direct reuse as an AI system prompt.*
